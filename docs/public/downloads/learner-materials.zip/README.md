# แบบฝึกหัด Power Automate Operations

ทุกข้อมูลในชุดนี้เป็นตัวอย่างสมมติ

1. [Exercise 1: Email flow](docs/exercises/01-foundation-email.md)
2. [Exercise 2: Forms → Excel](docs/exercises/02-forms-to-excel.md)
3. [Exercise 4: ChatGPT และ error repair](docs/exercises/04-chatgpt-design-and-troubleshooting.md)

[คู่มือ ChatGPT](docs/guidebook/index.md) · [ข้อมูลทดสอบ](docs/resources/sample-inputs.md) · [ไฟล์ฝึกและ reset](docs/resources/downloads.md)

ไฟล์ XLSX อยู่ใน docs/public/downloads/ ใช้ Markdown viewer ที่รองรับ Mermaid เพื่อดู diagrams
เว็บไซต์: https://teerasej.github.io/axa-power-automate-operations-2026/
