# Operations Day 1 - English learner materials

Start with the [overview](docs/index.md). Complete [Section 2 preparation](docs/resources/section-2-preparation.md) and [Section 3 preparation](docs/resources/section-3-preparation.md).

1. [Manual email](docs/exercises/01-foundation-email.md)
2. [Request routing](docs/exercises/02-forms-to-excel.md)
3. [Complete approval, then add a reminder](docs/exercises/03-document-approval.md)
4. [ChatGPT and error repair](docs/exercises/04-chatgpt-design-and-troubleshooting.md)

All [downloads and reset files](docs/resources/downloads.md) are included. Open Markdown in a viewer supporting relative links. Mermaid diagrams require a compatible viewer; website search is not part of this offline archive. The four headers and two instructional PNG images are included. Expected approval results are fictional examples, not run evidence. Use your own training account and workbook.
