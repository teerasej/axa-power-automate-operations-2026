# Operations Day 1 — English learner materials

Start with the [overview](docs/index.md), [preparation](docs/resources/section-2-preparation.md) and [exercises](docs/exercises/01-foundation-email.md).

The morning routing exercise uses a prepared Form and workbook, one Condition and two labelled emails to your own mailbox. The afternoon exercise will be provided after scenario selection. The final session supports images, text backups and instructor examples.

[Downloads and reset files](docs/resources/downloads.md) are included in docs/public/downloads. Use a Markdown viewer with relative-link support; Mermaid diagrams require a compatible viewer. PNG diagrams are also provided. All data is synthetic. Illustrations are not screenshots or run evidence.

English learner release, 14 October 2026.
