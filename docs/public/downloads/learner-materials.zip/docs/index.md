
## Before you begin

- Open Power Automate, Outlook, Microsoft Forms and OneDrive for Business with the training account confirmed by the organiser.
- Select the instructor's environment and use your own training email as recipient.
- Complete [Section 2 preparation](./resources/section-2-preparation.md) and download the [practice files](./resources/downloads.md).
- Use synthetic data only. Ask the instructor for help if you cannot access an app or create a connection.

> **Licences:** These exercises use Built-in actions and Standard connectors: Office 365 Outlook, Microsoft Forms and Excel Online (Business). No Premium connector is required, but Power Automate and the related Microsoft 365 service entitlements must be confirmed. Standard does not mean every service is free. Use an organisation-approved ChatGPT account; no particular paid plan or model is prescribed.

## Available exercises

1. [Exercise 1: Your first email flow](./exercises/01-foundation-email.md)
2. [Exercise 2: Smart Request Intake and Routing](./exercises/02-forms-to-excel.md)
3. [Exercise 4: ChatGPT design review and error repair](./exercises/04-chatgpt-design-and-troubleshooting.md)

Exercise numbers follow the teaching sections. Open activities in the order your instructor announces. Read [flow foundations](./resources/foundations.md), the [ChatGPT guidebook](./guidebook/index.md) and [test inputs](./resources/sample-inputs.md) as needed. Check both Run history and actual destination values; Succeeded alone does not prove the data is correct.

## Session rhythm

- **09:00–10:30:** foundations and your first email flow.
- **10:45–12:00:** prepared Form/workbook, one Condition and two routes to your own mailbox. Explanation 10 minutes, walkthrough 10, guided practice 30, tests 15 and recap/support 10.
- **13:00–14:30:** follow the afternoon activity announced by the instructor. This site includes only exercises ready for learner use.
- **14:45–16:00:** ChatGPT method 10 minutes, design review 20, controlled error/repair 30 and review/questions 15.

Breaks: 10:30–10:45 and 14:30–14:45. Lunch: 12:00–13:00. Use these breaks as breaks; required work stays inside the teaching sessions.
